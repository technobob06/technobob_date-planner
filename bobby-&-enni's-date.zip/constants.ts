
import { DateOption } from './types';

export const LOCATIONS: DateOption[] = [
  { id: '1', label: 'Урлагийн музей', emoji: '🖼️' },
  { id: '2', label: 'Ботаникийн цэцэрлэг', emoji: '🌿' },
  { id: '3', label: 'Далайн эрэг', emoji: '🌊' },
  { id: '4', label: 'Дээврийн бар', emoji: '🍸' },
  { id: '5', label: 'Хуучны кино театр', emoji: '🎬' },
  { id: '6', label: 'Хотын цэцэрлэгт хүрээлэн', emoji: '🌳' },
  { id: '7', label: 'Нууц жазз клуб', emoji: '🎷' },
  { id: '8', label: 'Хуучин хотын талбай', emoji: '🏘️' }
];

export const CUISINES: DateOption[] = [
  { id: '1', label: 'Итали паста', emoji: '🍝' },
  { id: '2', label: 'Сүши ба сакэ', emoji: '🍣' },
  { id: '3', label: 'Франц бистро', emoji: '🥖' },
  { id: '4', label: 'Солонгос барбекю', emoji: '🥩' },
  { id: '5', label: 'Мексик тако', emoji: '🌮' },
  { id: '6', label: 'Нарийн боовны газар', emoji: '🥐' },
  { id: '7', label: 'Дим сам', emoji: '🥟' },
  { id: '8', label: 'Бургер ба шарсан төмс', emoji: '🍔' }
];

export const ACTIVITIES: DateOption[] = [
  { id: '1', label: 'Шавар урлалын хичээл', emoji: '🏺' },
  { id: '2', label: 'Наран жаргах үеийн зугаалга', emoji: '🌅' },
  { id: '3', label: 'Гэрэл зургийн авалт', emoji: '📸' },
  { id: '4', label: 'Уран зураг зурах', emoji: '🎨' },
  { id: '5', label: 'Одод харах', emoji: '✨' },
  { id: '6', label: 'Хөлөгт тоглоомын кафе', emoji: '🎲' },
  { id: '7', label: 'Цэцгийн урлал', emoji: '💐' },
  { id: '8', label: 'Видео тоглоомын газар', emoji: '🕹️' }
];

export const THEME_COLORS = {
  cream: '#fdfbf7',
  pink: '#f4dada',
  sage: '#8e9775',
  charcoal: '#4a4a4a',
  accent: '#e5989b'
};
